import { Component } from '@angular/core';
//import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'SecondApp';
  public data:any=[];

  //constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService) {
     
//}
  constructor() {
     this.saveInLocal("aaa","bbbb");
     //console.log("zzzz:"+this.getFromLocal("aaa"));
  }

  saveInLocal(key, val): void {
    window.localStorage.setItem("aa","bbbbbbbbbbbbb");
   }

   getFromLocal(key): void {
    console.log("zzzzzzzzz: "+window.localStorage.getItem("aa"));
   }
}
