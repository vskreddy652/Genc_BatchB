import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
  export class AppComponent {
    title = 'SimpleTitle';
    points = 1;

    plus1() {
     // debugger;
      this.points++;
    }

    reset() {
      this.points = 0;
    }
}
