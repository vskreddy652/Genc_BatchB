
import { Component } from '@angular/core';

@Component({
  selector: 'hero-form-template',
  templateUrl: './hero-form-template.component.html'
})
export class HeroFormTemplateComponent {

  powers = ['Really Smart', 'Super Flexible', 'Weather Changer'];

  hero = {name: 'Drr.', alterEgo: 'Dr. What', power: this.powers[0]};

}
