.parent-menu ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
.parent-menu li {
    float: left;
}
.parent-menu li a {
    display: block;
    color: white;
    text-align: center;
    padding: 15px 15px;
    text-decoration: none;
}
.parent-menu li a:hover:not(.active) {
    background-color: #111;
}
.parent-menu .active{
    background-color: #4CAF50;
}
.sub-menu ul {
   list-style-type: none;
   padding: 0;
}
.sub-menu li {
   display: inline-block;
   width: 120px;
   line-height: 50px;
   padding: 0 10px;
   box-sizing: border-box;
   background-color: #eee;
   border-radius: 4px;
   margin: 10px;
   cursor: pointer;
   overflow: hidden;
   white-space: nowrap;
}