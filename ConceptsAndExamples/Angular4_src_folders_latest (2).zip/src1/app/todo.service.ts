import {Injectable}               from '@angular/core';
import {Http, Response}           from '@angular/http';
import {Headers, RequestOptions}  from '@angular/http';
//import {Observable}               from 'rxjs/Observable';
import {Observable} from "rxjs/Rx";
import {Todo}                     from './todo';

@Injectable()
export class TodoService {
  
  constructor (private http: Http) {}

  private _todosUrl = 'http://www.excelurgyan.com/check/todos.json';

  getTodos () {
    return this.http.get(this._todosUrl)
              .toPromise()
              .then(res => <Todo[]> res.json().data)
              .then(data => { console.log(data); return data; }); // results in the console
  }

  private handleError (error: Response) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }
}