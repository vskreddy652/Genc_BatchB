import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
    <h2>About</h2>
    <a [routerLink]="['/about']">Home</a>
    <a [routerLink]="['/about/item']">Item</a>
    <div>
      <router-outlet></router-outlet>
    </div>
  `
})
export class AboutComponent { }