import { Component } from '@angular/core';

@Component({
    selector: 'app-helpadmin',
    template: `<h2>Help-Admin</h2>`
  })
  export class HelpAdminComponent { }