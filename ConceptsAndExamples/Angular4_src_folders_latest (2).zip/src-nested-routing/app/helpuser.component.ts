import { Component } from '@angular/core';

@Component({
    selector: 'app-helpuser',
    template: `<h2>HelpUser</h2>`
  })
  export class HelpUserComponent { }