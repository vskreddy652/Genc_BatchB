import { Routes } from '@angular/router';

import { AboutComponent } from './about.component';
import { AboutItemComponent } from './about.item.component';
import { AboutHomeComponent } from './about.home.component';
import { HomeComponent } from './home.component';
import { HelpComponent } from './help.component';
import {HelpUserComponent} from './helpuser.component';
import { HelpAdminComponent } from './helpadmin.component';


//all routes one level and multiple level need to be specified here
export const routes: Routes = [
  { path: '', component: HomeComponent },//components which do not have children
  { path: 'help', component: HelpComponent,
    children: [
      {path:'user', component: HelpUserComponent}, 
      {path:'admin', component:HelpAdminComponent}
    ]
},//components which do not have children
  {//component which has children
    path: 'about', 
    component: AboutComponent,
    children: [//children of about component
      { path: '', component: AboutHomeComponent }, // url: about/
      { path: 'item', component: AboutItemComponent } // url: about/item
    ],
  }
];
