import { Component } from '@angular/core';

@Component({
  selector: 'about-item',
  template: `<h3>About Item</h3>`
})
export class AboutItemComponent { }