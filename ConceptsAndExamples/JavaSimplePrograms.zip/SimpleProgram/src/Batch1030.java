class ArthDemo
{
	int i,j;
	
	void add()
	{
		System.out.println("Result is:");
	}
}

public class Batch1030 {
	public static void main(String a[])
	{
		
	}
}
