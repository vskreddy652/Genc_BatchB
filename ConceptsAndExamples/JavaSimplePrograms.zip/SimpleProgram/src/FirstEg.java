
class Arith{
	int i,j;
	
	Arith(int a, int b)
	{
		i = a;
		j = b;
	}
	
	int add()
	{
		int k;
		k=i+j;
		
		return k;
	}
}

public class FirstEg {
	public static void main(String[] args) {
		
	}
}
