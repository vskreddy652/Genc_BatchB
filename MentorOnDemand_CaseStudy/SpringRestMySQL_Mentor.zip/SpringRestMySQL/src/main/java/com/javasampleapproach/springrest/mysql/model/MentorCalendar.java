package com.javasampleapproach.springrest.mysql.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentorcalendar")
public class MentorCalendar {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int mid;
	
	private Date start_date;
	private Date end_date;
	
	
	public MentorCalendar() {}
	
	public MentorCalendar(int id, int mid, Date start_date, Date end_date) {
		super();
		this.id = id;
		this.mid = mid;
		this.start_date = start_date;
		this.end_date = end_date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	
}
