package com.javasampleapproach.springrest.mysql.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.MentorSKills;
import com.javasampleapproach.springrest.mysql.model.Tranings;
import com.javasampleapproach.springrest.mysql.model.TraningsModel;
import com.javasampleapproach.springrest.mysql.repo.CustomerRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorSkillsRepository;
import com.javasampleapproach.springrest.mysql.repo.TrainingsRepository;

@CrossOrigin(origins = "*")
@RestController
public class MentorSkillsRestController {
	@Autowired
	MentorSkillsRepository repository;
	
	@GetMapping("/searchMentors")
	List<Object[]> getCompletedTranings()
	{
		List<Object[]> lms = repository.findBySkillIdDateRange((long)2, "2019-09-30 00:00:00", "2019-10-26 00:00:00");
		System.out.println("LMS:"+lms);
		return lms;
	}
}
