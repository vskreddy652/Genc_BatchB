package com.javasampleapproach.springrest.mysql.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.javasampleapproach.springrest.mysql.model.Customer;
import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.MentorSKills;
import com.javasampleapproach.springrest.mysql.model.Tranings;

public interface MentorSkillsRepository extends CrudRepository<Mentor, Long> {
	/*String findBySkillIdAndDateRange = "SELECT * FROM Mentor_Skills ms "
			+ "WHERE ms.skill_id=?1 AND ms.mentor_id NOT IN ("
			+ "  SELECT DISTINCT mc.mentor_id FROM Mentor_Calendar mc " + 
			"    WHERE (mc.start_date BETWEEN ?2 AND ?3 AND mc.end_date BETWEEN ?2 AND ?3) AND " + 
			"          (mc.start_time BETWEEN ?4 AND ?5 AND mc.end_time BETWEEN ?4 AND ?5) "
			+ ")";*/
	
	String findBySkillIdAndDateRange = "SELECT * FROM mentorskills ms WHERE ms.sid=?1 AND ms.mid "
			+ "NOT IN (SELECT DISTINCT mc.mid FROM mentorcalendar mc WHERE "
			+ "((mc.start_date BETWEEN ?2 AND ?3)"
			+ "OR (mc.end_date BETWEEN ?2 AND ?3)))";
	@Query(value = findBySkillIdAndDateRange, nativeQuery = true)
	List<Object[]> findBySkillIdDateRange(Long skillId, String startDateTime, String endDateTime);
	
}
