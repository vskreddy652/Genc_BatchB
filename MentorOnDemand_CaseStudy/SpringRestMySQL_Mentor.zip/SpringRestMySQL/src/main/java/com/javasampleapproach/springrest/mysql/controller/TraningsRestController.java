package com.javasampleapproach.springrest.mysql.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.Tranings;
import com.javasampleapproach.springrest.mysql.model.TraningsModel;
import com.javasampleapproach.springrest.mysql.repo.CustomerRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
import com.javasampleapproach.springrest.mysql.repo.TrainingsRepository;

@CrossOrigin(origins = "*")
@RestController
public class TraningsRestController {
	@Autowired
	TrainingsRepository repository;
	
	@Autowired
	MentorRepository mrepository;
	
	@GetMapping("/getCompletedTrainings")
	List<TraningsModel> getCompletedTranings()
	{
		List<Tranings> tranings_list = repository.findByStatusAndUserId(5, 1);
		List<TraningsModel> traningsm_list = new ArrayList<TraningsModel>();
		for(Tranings tranings:tranings_list)
		{
			int mentor_id = tranings.getMentorid();
			Optional<Mentor> mentor = mrepository.findById((long) mentor_id);
			
			//(long id, int userid, String mentor_username, int status, int progress)
			TraningsModel tmodel = new TraningsModel(tranings.getId(),
					tranings.getUserid(), mentor.get().getUsername(), tranings.getStatus(),
					tranings.getProgress());
			
			traningsm_list.add(tmodel);
		}
		
		return traningsm_list;
	}
}
