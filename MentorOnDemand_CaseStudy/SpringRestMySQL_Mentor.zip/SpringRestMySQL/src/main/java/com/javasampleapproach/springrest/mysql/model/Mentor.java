package com.javasampleapproach.springrest.mysql.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mentor")
public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "username")
	private String username;

	@Column(name = "linkedin_url")
	private String linkedin_url;
	
	@Column(name = "created_datetime")
	private Date created_datetime;

	@Column(name = "regcode")
	private String regcode;
	
	@Column(name = "years_of_experience")
	private int years_of_experience;

	@Column(name = "active")
	private boolean active;

	public Mentor() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLinkedin_url() {
		return linkedin_url;
	}

	public void setLinkedin_url(String linkedin_url) {
		this.linkedin_url = linkedin_url;
	}

	public Date getCreated_datetime() {
		return created_datetime;
	}

	public void setCreated_datetime(Date created_datetime) {
		this.created_datetime = created_datetime;
	}

	public String getRegcode() {
		return regcode;
	}

	public void setRegcode(String regcode) {
		this.regcode = regcode;
	}

	public int getYears_of_experience() {
		return years_of_experience;
	}

	public void setYears_of_experience(int years_of_experience) {
		this.years_of_experience = years_of_experience;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", username=" + username + ", linkedin_url=" + linkedin_url + ", created_datetime="
				+ created_datetime + ", regcode=" + regcode + ", years_of_experience=" + years_of_experience
				+ ", active=" + active + "]";
	}

	
}
