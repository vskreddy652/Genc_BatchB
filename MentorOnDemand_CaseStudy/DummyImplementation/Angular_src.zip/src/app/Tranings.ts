export class Tranings {
    id: number;
    userid: number;
    mentorid: number;
    status: number;
    progress: number;
    /*
    {"id":2,"userid":1,"mentorid":11,"status":5,"progress":5}
    */

}
